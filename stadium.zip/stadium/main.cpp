/*Name leyla Tulu
  ID   Ramit/1166/11
  Section C
  Graphics asssignment
  */ 

#include<gl/glut.h>
#include<math.h>
void display(){
	glClear(GL_COLOR_BUFFER_BIT);
	glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-4.0,30.0,-4.0,30.0);   
	
	glColor3f(0.4,0.0,0.0);
    glBegin(GL_QUADS);
	glVertex2f(-4.0,-4.0);
    glVertex2f(30.0,-4.0);
    glVertex2f(30.0,30.0);
    glVertex2f(-4.0,30.0);
	glEnd();

	glColor3f(1.0,1.0,1.0);
    glBegin(GL_QUADS);
	glVertex2f(0.0,0.0);
    glVertex2f(26.0,0.0);
    glVertex2f(26.0,26.0);
    glVertex2f(0.0,26.0);
	glEnd();

	glColor3f(0.0,0.5,0.0);
    glBegin(GL_QUADS);
	glVertex2f(2.0,2.0);
    glVertex2f(24.0,2.0);
    glVertex2f(24.0,22.0);
    glVertex2f(2.0,22.0);
	glEnd();
    

	glColor3f(1.0,1.0,1.0);
	glBegin(GL_LINES);
	glVertex2f(13.0,4.0);
	glVertex2f(13.0,20.0);
	glEnd();
	
    glColor3f(1.0,1.0,1.0);
	glBegin(GL_LINES);
    glVertex2f(4.0,4.0);
    glVertex2f(22.0,4.0);
    glVertex2f(22.0,20.0);
    glVertex2f(4.0,20.0);
    glVertex2f(4.0,4.0);
    glVertex2f(4.0,20.0);
    glVertex2f(22.0,20.0);
    glVertex2f(22.0,4.0);
	glEnd();
	
	glColor3f(1.0,1.0,1.0);
   	glBegin(GL_LINES);
	glVertex2f(22.0,7.0);
    glVertex2f(19.0,7.0);
    glVertex2f(22.0,17.0);
    glVertex2f(19.0,17.0);
    glVertex2f(19.0,7.0);
    glVertex2f(19.0,17.0);
   	glEnd();
	
	glColor3f(1.0,1.0,1.0);
   	glBegin(GL_LINES);
	glVertex2f(21.0,10.0);
    glVertex2f(22.0,10.0);
    glVertex2f(21.0,14.0);
    glVertex2f(22.0,14.0);
    glVertex2f(21.0,10.0);
    glVertex2f(21.0,14.0);
   	glEnd();
    
    glVertex2f(22.0,4.0);
    glVertex2f(22.0,20.0);
    glVertex2f(4.0,20.0);
    glVertex2f(4.0,4.0);
    glVertex2f(4.0,20.0);
    glVertex2f(22.0,20.0);
    glVertex2f(22.0,4.0);
    glEnd();
    
    glColor3f(1.0,1.0,1.0);
   	glBegin(GL_LINES);
	glVertex2f(7.0,7.0);
    glVertex2f(4.0,7.0);
    glVertex2f(7.0,17.0);
    glVertex2f(4.0,17.0);
    glVertex2f(7.0,17.0);
    glVertex2f(7.0,7.0);
   	glEnd();
    
    glColor3f(1.0,1.0,1.0);
   	glBegin(GL_LINES);
	glVertex2f(5.0,10.0);
    glVertex2f(4.0,10.0);
    glVertex2f(5.0,14.0);
    glVertex2f(4.0,14.0);
    glVertex2f(5.0,10.0);
    glVertex2f(5.0,14.0);
   	glEnd();
   	
  
    glLineWidth(0.1);
    glColor3f(1.0,1.0,1.0);
   	glBegin(GL_LINES);
	glVertex2f(4.0,13.0);
    glVertex2f(3.5,13.0);
    glVertex2f(3.5,11.0);
    glVertex2f(3.5,13.0);
    glVertex2f(4.0,11.0);
    glVertex2f(3.5,11.0);
   	glEnd();
    
     glColor3f(1.0,1.0,1.0);
   	glBegin(GL_LINES);
	glVertex2f(22.5,13.0);
    glVertex2f(22.5,11.0);
    glVertex2f(22.5,11.0);
    glVertex2f(22.0,11.0);
    glVertex2f(22.5,13.0);
    glVertex2f(22.0,13.0);
   	glEnd();
    
   
    glColor3f(1.0,1.0,1.0);
   	glBegin(GL_LINES);
	glVertex2f(3.6,13.0);
    glVertex2f(3.6,11.0);
    glVertex2f(3.7,13.0);
    glVertex2f(3.7,11.0);
    glVertex2f(3.8,13.0);
    glVertex2f(3.8,11.0);
    glVertex2f(3.9,13.0);
    glVertex2f(3.9,11.0);
   	glEnd();
    
    glColor3f(1.0,1.0,1.0);
   	glBegin(GL_LINES);
	glVertex2f(3.5,11.3);
    glVertex2f(4.0,11.3);
    glVertex2f(3.5,11.6);
    glVertex2f(4.0,11.6);
    glVertex2f(3.5,11.9);
    glVertex2f(4.0,11.9);
    glVertex2f(3.5,12.2);
    glVertex2f(4.0,12.2);
    glVertex2f(4.0,12.5);
    glVertex2f(3.5,12.5);
    glVertex2f(4.0,12.8);
    glVertex2f(3.5,12.8);
   	glEnd();
    
     glColor3f(1.0,1.0,1.0);
   	glBegin(GL_LINES);
	glVertex2f(22.1,11.0);
    glVertex2f(22.1,13.0);
    glVertex2f(22.2,11);
    glVertex2f(22.2,13.0);
    glVertex2f(22.3,11.0);
    glVertex2f(22.3,13.0);
    glVertex2f(22.4,11.0);
    glVertex2f(22.4,13.0);
   	glEnd();
   	
   	glLineWidth(0.1);
   	 glColor3f(1.0,1.0,1.0);
   	glBegin(GL_LINES);
	glVertex2f(22.5,11.3);
    glVertex2f(22.0,11.3);
    glVertex2f(22.5,11.6);
    glVertex2f(22.0,11.6);
    glVertex2f(22.5,11.9);
    glVertex2f(22.0,11.9);
    glVertex2f(22.5,12.2);
    glVertex2f(22.0,12.2);
    glVertex2f(22.0,12.5);
    glVertex2f(22.5,12.5);
    glVertex2f(22.0,12.8);
    glVertex2f(22.5,12.8);
   	glEnd();
   	
   	glColor3f(1.0,1.0,1.0);
	glBegin(GL_LINES);
	glVertex2f(13.0,4.0);
	glVertex2f(13.0,20.0);
	glEnd();

glLineWidth(3.0);
   	glColor3f(1.0,1.0,1.0);
   	glBegin(GL_LINE_LOOP);
   	for(int i=0;i<360;i++)
{
	float d=i*3.142/180;
	glVertex2f(13.0+1.5*cos(d),12.0+1.5*sin(d));
		}   
		glEnd(); 
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_POLYGON);
   	for(int i=0;i<360;i++)
{
	float d=i*3.142/180;
	glVertex2f(13.0+0.1*cos(d),12.0+0.1*sin(d));
		}    
   glEnd();
   
   	
	   glColor3f(1.0,1.0,1.0);
	glBegin(GL_POLYGON);
   	for(int i=0;i<360;i++)
{
	float d=i*3.142/180;
	glVertex2f(6.0+0.1*cos(d),12.0+0.1*sin(d));
		}    
   glEnd();
   
   
  	glBegin(GL_POLYGON);
    	glColor3f(1.0,1.0,1.0);
   	for(int i=0;i<360;i++)
{
	float d=i*3.142/180;
	glVertex2f(20.0+0.1*cos(d),12.0+0.1*sin(d));
		}    
   glEnd();
   
     glLineWidth(3);
    	glColor3f(1.0,1.0,1.0);
	glBegin(GL_LINE_STRIP);
   	for(int i=90;i<270;i++)
{
	float d=i*3.142/180;
	glVertex2f(19.0+0.8*cos(d),12.0+1.5*sin(d));
		}    
   glEnd();
   
 
   
   
   
      	glColor3f(1.0,1.0,1.0);
		glBegin(GL_LINE_STRIP);
   	for(int i=270;i<450;i++)
{
	float d=i*3.142/180;
	glVertex2f(7.0+0.8*cos(d),12.0+1.5*sin(d));
		}    
   glEnd();
   
  
    	glColor3f(1.0,1.0,1.0);
	glBegin(GL_LINE_STRIP);
   	for(int i=0;i<90;i++)
{
	float d=i*3.142/180;
	glVertex2f(4.0+0.7*cos(d),4.0+0.9*sin(d));
		}    
   glEnd();
   
   	glColor3f(1.0,1.0,1.0);
	glBegin(GL_LINE_STRIP);
   	for(int i=90;i<180;i++)
{
	float d=i*3.142/180;
	glVertex2f(22.0+0.7*cos(d),4.0+0.9*sin(d));
		}    
   glEnd();
   
   
   
   	glColor3f(1.0,1.0,1.0);
	glBegin(GL_LINE_STRIP);
   	for(int i=270;i<360;i++)
{
	float d=i*3.142/180;
	glVertex2f(4.0+0.7*cos(d),20.0+0.9*sin(d));
		}    
   glEnd();
   

   
   	glColor3f(1.0,1.0,1.0);
	glBegin(GL_LINE_STRIP);
	
   	for(int i=180;i<270;i++)
{
	float d=i*3.142/180;
	glVertex2f(22.0+0.7*cos(d),20.0+0.9*sin(d));
		}    
   glEnd();
   
	glFlush();

}   
int main(int argc, char** argv) {
	glutInit(&argc,argv);	
	glutInitWindowSize(1400,1200);
	glutInitWindowPosition(0,0);
	glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB);
	glutCreateWindow("Leyla's assignment");
	glutDisplayFunc(display);
	glutMainLoop();
	return 0;
}
